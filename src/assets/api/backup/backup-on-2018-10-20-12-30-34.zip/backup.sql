#
# TABLE STRUCTURE FOR: convt
#

DROP TABLE IF EXISTS `convt`;

CREATE TABLE `convt` (
  `convtID` int(7) NOT NULL AUTO_INCREMENT,
  `conv_itemID` int(11) NOT NULL,
  `conv_date` datetime NOT NULL,
  `conv_crt` int(7) NOT NULL,
  `conv_piece` int(7) NOT NULL,
  PRIMARY KEY (`convtID`),
  KEY `conv_itemID` (`conv_itemID`),
  CONSTRAINT `convt_ibfk_1` FOREIGN KEY (`conv_itemID`) REFERENCES `item` (`itemID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: invoice
#

DROP TABLE IF EXISTS `invoice`;

CREATE TABLE `invoice` (
  `invID` int(11) NOT NULL AUTO_INCREMENT,
  `inv_perID` int(5) NOT NULL,
  `inv_code` varchar(7) NOT NULL,
  `inv_type` varchar(2) NOT NULL,
  `inv_date_req` datetime NOT NULL,
  `inv_date_del` date DEFAULT NULL,
  `inv_status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`invID`),
  KEY `inv_PID` (`inv_perID`),
  CONSTRAINT `invoice_ibfk_1` FOREIGN KEY (`inv_perID`) REFERENCES `person` (`perID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: item
#

DROP TABLE IF EXISTS `item`;

CREATE TABLE `item` (
  `itemID` int(11) NOT NULL AUTO_INCREMENT,
  `item_is_damaged` tinyint(1) NOT NULL DEFAULT '0',
  `item_code` varchar(7) NOT NULL,
  `item_name` varchar(200) NOT NULL,
  `item_packing_list` int(5) NOT NULL,
  `item_piece` int(9) NOT NULL DEFAULT '0',
  `item_isActivated` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`itemID`,`item_is_damaged`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: order_inv
#

DROP TABLE IF EXISTS `order_inv`;

CREATE TABLE `order_inv` (
  `ordID` int(11) NOT NULL AUTO_INCREMENT,
  `ord_invID` int(11) NOT NULL,
  `ord_itemID` int(11) NOT NULL,
  `ord_item_isDamaged` tinyint(1) NOT NULL DEFAULT '0',
  `ord_crt` int(9) DEFAULT '0',
  `ord_piece` int(9) DEFAULT '0',
  `ord_note` varchar(100) DEFAULT NULL,
  `ord_isDeleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ordID`),
  KEY `ord_invID` (`ord_invID`),
  KEY `ord_itemID` (`ord_itemID`),
  KEY `ord_item_isDamaged` (`ord_item_isDamaged`),
  CONSTRAINT `order_inv_ibfk_1` FOREIGN KEY (`ord_invID`) REFERENCES `invoice` (`invID`) ON DELETE CASCADE,
  CONSTRAINT `order_inv_ibfk_2` FOREIGN KEY (`ord_itemID`) REFERENCES `item` (`itemID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: person
#

DROP TABLE IF EXISTS `person`;

CREATE TABLE `person` (
  `perID` int(5) NOT NULL AUTO_INCREMENT,
  `per_code` varchar(7) NOT NULL,
  `per_name` varchar(50) NOT NULL,
  `per_phone` varchar(50) DEFAULT NULL,
  `per_address` varchar(100) DEFAULT NULL,
  `per_isActivated` tinyint(1) NOT NULL DEFAULT '1',
  `per_isClient` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`perID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `person` (`perID`, `per_code`, `per_name`, `per_phone`, `per_address`, `per_isActivated`, `per_isClient`) VALUES (1, 'supp', 'Supplier', NULL, NULL, 1, 0);


#
# TABLE STRUCTURE FOR: return_details
#

DROP TABLE IF EXISTS `return_details`;

CREATE TABLE `return_details` (
  `date_ordID` int(11) NOT NULL,
  `ord_perID` int(5) NOT NULL,
  `ord_date_req` date DEFAULT NULL,
  `ord_date_com` date DEFAULT NULL,
  `ord_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`date_ordID`),
  KEY `date_ordID` (`date_ordID`),
  KEY `ord_perID` (`ord_perID`),
  CONSTRAINT `return_details_ibfk_1` FOREIGN KEY (`date_ordID`) REFERENCES `order_inv` (`ordID`),
  CONSTRAINT `return_details_ibfk_2` FOREIGN KEY (`ord_perID`) REFERENCES `person` (`perID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

