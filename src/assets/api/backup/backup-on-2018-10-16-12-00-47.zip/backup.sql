#
# TABLE STRUCTURE FOR: convt
#

DROP TABLE IF EXISTS `convt`;

CREATE TABLE `convt` (
  `convtID` int(7) NOT NULL AUTO_INCREMENT,
  `conv_itemID` int(11) NOT NULL,
  `conv_date` datetime NOT NULL,
  `conv_crt` int(7) NOT NULL,
  `conv_piece` int(7) NOT NULL,
  PRIMARY KEY (`convtID`),
  KEY `conv_itemID` (`conv_itemID`),
  CONSTRAINT `convt_ibfk_1` FOREIGN KEY (`conv_itemID`) REFERENCES `item` (`itemID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: invoice
#

DROP TABLE IF EXISTS `invoice`;

CREATE TABLE `invoice` (
  `invID` int(11) NOT NULL AUTO_INCREMENT,
  `inv_perID` int(5) NOT NULL,
  `inv_code` varchar(7) NOT NULL,
  `inv_type` varchar(2) NOT NULL,
  `inv_date_req` datetime NOT NULL,
  `inv_date_del` date DEFAULT NULL,
  `inv_status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`invID`),
  KEY `inv_PID` (`inv_perID`),
  CONSTRAINT `invoice_ibfk_1` FOREIGN KEY (`inv_perID`) REFERENCES `person` (`perID`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

INSERT INTO `invoice` (`invID`, `inv_perID`, `inv_code`, `inv_type`, `inv_date_req`, `inv_date_del`, `inv_status`) VALUES (1, 1, 'FD00001', 'FD', '2018-10-10 14:51:04', NULL, 1);
INSERT INTO `invoice` (`invID`, `inv_perID`, `inv_code`, `inv_type`, `inv_date_req`, `inv_date_del`, `inv_status`) VALUES (2, 2, 'FC00001', 'FC', '2018-10-10 14:52:08', '2018-10-10', 1);
INSERT INTO `invoice` (`invID`, `inv_perID`, `inv_code`, `inv_type`, `inv_date_req`, `inv_date_del`, `inv_status`) VALUES (3, 4, 'FC00002', 'FC', '2018-10-15 12:38:39', '2018-10-15', 1);
INSERT INTO `invoice` (`invID`, `inv_perID`, `inv_code`, `inv_type`, `inv_date_req`, `inv_date_del`, `inv_status`) VALUES (4, 3, 'FR00001', 'FR', '2018-10-15 16:25:43', NULL, 1);
INSERT INTO `invoice` (`invID`, `inv_perID`, `inv_code`, `inv_type`, `inv_date_req`, `inv_date_del`, `inv_status`) VALUES (5, 2, 'FR00002', 'FR', '2018-10-15 17:23:06', NULL, 1);
INSERT INTO `invoice` (`invID`, `inv_perID`, `inv_code`, `inv_type`, `inv_date_req`, `inv_date_del`, `inv_status`) VALUES (6, 3, 'FR00003', 'FR', '2018-10-15 17:24:53', NULL, 1);
INSERT INTO `invoice` (`invID`, `inv_perID`, `inv_code`, `inv_type`, `inv_date_req`, `inv_date_del`, `inv_status`) VALUES (7, 5, 'FR00004', 'FR', '2018-10-15 17:26:20', NULL, -1);


#
# TABLE STRUCTURE FOR: item
#

DROP TABLE IF EXISTS `item`;

CREATE TABLE `item` (
  `itemID` int(11) NOT NULL AUTO_INCREMENT,
  `item_is_damaged` tinyint(1) NOT NULL DEFAULT '0',
  `item_code` varchar(7) NOT NULL,
  `item_name` varchar(200) NOT NULL,
  `item_packing_list` int(5) NOT NULL,
  `item_piece` int(9) NOT NULL DEFAULT '0',
  `item_isActivated` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`itemID`,`item_is_damaged`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `item` (`itemID`, `item_is_damaged`, `item_code`, `item_name`, `item_packing_list`, `item_piece`, `item_isActivated`) VALUES (1, 0, 'ASD0001', 'asdasd', 23, 25, 1);
INSERT INTO `item` (`itemID`, `item_is_damaged`, `item_code`, `item_name`, `item_packing_list`, `item_piece`, `item_isActivated`) VALUES (2, 0, 'ASD0002', 'asd', 22, 0, 1);


#
# TABLE STRUCTURE FOR: order_inv
#

DROP TABLE IF EXISTS `order_inv`;

CREATE TABLE `order_inv` (
  `ordID` int(11) NOT NULL AUTO_INCREMENT,
  `ord_invID` int(11) NOT NULL,
  `ord_itemID` int(11) NOT NULL,
  `ord_item_isDamaged` tinyint(1) NOT NULL DEFAULT '0',
  `ord_crt` int(9) DEFAULT '0',
  `ord_piece` int(9) DEFAULT '0',
  `ord_note` varchar(100) DEFAULT NULL,
  `ord_isDeleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ordID`),
  KEY `ord_invID` (`ord_invID`),
  KEY `ord_itemID` (`ord_itemID`),
  KEY `ord_item_isDamaged` (`ord_item_isDamaged`),
  CONSTRAINT `order_inv_ibfk_1` FOREIGN KEY (`ord_invID`) REFERENCES `invoice` (`invID`) ON DELETE CASCADE,
  CONSTRAINT `order_inv_ibfk_2` FOREIGN KEY (`ord_itemID`) REFERENCES `item` (`itemID`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

INSERT INTO `order_inv` (`ordID`, `ord_invID`, `ord_itemID`, `ord_item_isDamaged`, `ord_crt`, `ord_piece`, `ord_note`, `ord_isDeleted`) VALUES (1, 1, 1, 0, 5, 15, '', 0);
INSERT INTO `order_inv` (`ordID`, `ord_invID`, `ord_itemID`, `ord_item_isDamaged`, `ord_crt`, `ord_piece`, `ord_note`, `ord_isDeleted`) VALUES (2, 2, 1, 0, 32, 2, '', 0);
INSERT INTO `order_inv` (`ordID`, `ord_invID`, `ord_itemID`, `ord_item_isDamaged`, `ord_crt`, `ord_piece`, `ord_note`, `ord_isDeleted`) VALUES (3, 3, 1, 0, 1, 2, '', 0);
INSERT INTO `order_inv` (`ordID`, `ord_invID`, `ord_itemID`, `ord_item_isDamaged`, `ord_crt`, `ord_piece`, `ord_note`, `ord_isDeleted`) VALUES (4, 4, 1, 0, 1, 11, NULL, 0);
INSERT INTO `order_inv` (`ordID`, `ord_invID`, `ord_itemID`, `ord_item_isDamaged`, `ord_crt`, `ord_piece`, `ord_note`, `ord_isDeleted`) VALUES (5, 5, 1, 0, 23, 22, NULL, 0);
INSERT INTO `order_inv` (`ordID`, `ord_invID`, `ord_itemID`, `ord_item_isDamaged`, `ord_crt`, `ord_piece`, `ord_note`, `ord_isDeleted`) VALUES (6, 6, 1, 0, 2, 2, NULL, 0);
INSERT INTO `order_inv` (`ordID`, `ord_invID`, `ord_itemID`, `ord_item_isDamaged`, `ord_crt`, `ord_piece`, `ord_note`, `ord_isDeleted`) VALUES (7, 7, 1, 0, 1, 2, NULL, 0);
INSERT INTO `order_inv` (`ordID`, `ord_invID`, `ord_itemID`, `ord_item_isDamaged`, `ord_crt`, `ord_piece`, `ord_note`, `ord_isDeleted`) VALUES (8, 7, 2, 0, 1, 2, NULL, 0);


#
# TABLE STRUCTURE FOR: person
#

DROP TABLE IF EXISTS `person`;

CREATE TABLE `person` (
  `perID` int(5) NOT NULL AUTO_INCREMENT,
  `per_code` varchar(7) NOT NULL,
  `per_name` varchar(50) NOT NULL,
  `per_phone` varchar(50) DEFAULT NULL,
  `per_address` varchar(100) DEFAULT NULL,
  `per_isActivated` tinyint(1) NOT NULL DEFAULT '1',
  `per_isClient` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`perID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `person` (`perID`, `per_code`, `per_name`, `per_phone`, `per_address`, `per_isActivated`, `per_isClient`) VALUES (1, 'supp', 'Supplier', NULL, NULL, 1, 0);
INSERT INTO `person` (`perID`, `per_code`, `per_name`, `per_phone`, `per_address`, `per_isActivated`, `per_isClient`) VALUES (2, 'ABC0001', 'abc', '232323', 'dasdas', 1, 1);
INSERT INTO `person` (`perID`, `per_code`, `per_name`, `per_phone`, `per_address`, `per_isActivated`, `per_isClient`) VALUES (3, 'ASD0001', 'asdas', 'sda', 'dasd', 1, 1);
INSERT INTO `person` (`perID`, `per_code`, `per_name`, `per_phone`, `per_address`, `per_isActivated`, `per_isClient`) VALUES (4, 'ASD0002', 'asdasd', 'dasd', 'sad', 1, 1);
INSERT INTO `person` (`perID`, `per_code`, `per_name`, `per_phone`, `per_address`, `per_isActivated`, `per_isClient`) VALUES (5, 'ASD0003', 'asd', 'as', 'dsaa', 1, 1);


#
# TABLE STRUCTURE FOR: return_details
#

DROP TABLE IF EXISTS `return_details`;

CREATE TABLE `return_details` (
  `date_ordID` int(11) NOT NULL,
  `ord_perID` int(5) NOT NULL,
  `ord_date_req` date DEFAULT NULL,
  `ord_date_com` date DEFAULT NULL,
  `ord_status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`date_ordID`),
  KEY `date_ordID` (`date_ordID`),
  KEY `ord_perID` (`ord_perID`),
  CONSTRAINT `return_details_ibfk_1` FOREIGN KEY (`date_ordID`) REFERENCES `order_inv` (`ordID`),
  CONSTRAINT `return_details_ibfk_2` FOREIGN KEY (`ord_perID`) REFERENCES `person` (`perID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `return_details` (`date_ordID`, `ord_perID`, `ord_date_req`, `ord_date_com`, `ord_status`) VALUES (4, 3, '2018-10-15', '2018-10-15', 1);
INSERT INTO `return_details` (`date_ordID`, `ord_perID`, `ord_date_req`, `ord_date_com`, `ord_status`) VALUES (5, 2, '2018-10-15', '2018-10-15', 1);
INSERT INTO `return_details` (`date_ordID`, `ord_perID`, `ord_date_req`, `ord_date_com`, `ord_status`) VALUES (6, 3, '2018-10-15', '2018-10-15', 1);
INSERT INTO `return_details` (`date_ordID`, `ord_perID`, `ord_date_req`, `ord_date_com`, `ord_status`) VALUES (7, 5, '2018-10-15', '2018-10-15', 1);
INSERT INTO `return_details` (`date_ordID`, `ord_perID`, `ord_date_req`, `ord_date_com`, `ord_status`) VALUES (8, 5, '2018-10-15', NULL, 0);


